########################################################
### Gossip Protocol Node 
########################################################
from Gossip import GossipNode
hostname = '192.168.4.25'
port = 8888
other_nodes = ['192.168.4.25']
node = GossipNode(port, hostname, other_nodes)



